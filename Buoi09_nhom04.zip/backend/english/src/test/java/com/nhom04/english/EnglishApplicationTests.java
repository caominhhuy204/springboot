package com.nhom04.english;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnglishApplicationTests {

	@Test
	void contextLoads() {
	}

}
